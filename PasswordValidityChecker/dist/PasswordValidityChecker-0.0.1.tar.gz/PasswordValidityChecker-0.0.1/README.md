#PasswordValidityChecker
a password validity checker that checks if your password:
-is 6-16 charecters long
-has at least 1 lower case character
-has at least 1 upper case character
-has at least 1 number
-has a "#", "$" or a "@"
