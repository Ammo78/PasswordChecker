# PasswordChecker
a password validity checker that checks if your password:
- is 6 to 16 charecters long
- has at least 1 lower case letter
- has at least 1 upper case letter
- has at least 1 "#", "$" or "@"
