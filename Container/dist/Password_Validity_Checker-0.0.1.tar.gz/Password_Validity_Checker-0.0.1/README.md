#Password_Validity_Checker
A password validity checker that checks if a password:
- has at least 1 lower case letter
- has at least 1 upper case letter
- has at least 1 number
- has at least 1 "$", "#" or "@"